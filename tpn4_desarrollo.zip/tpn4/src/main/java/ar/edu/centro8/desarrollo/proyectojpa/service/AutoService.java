package ar.edu.centro8.desarrollo.proyectojpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.edu.centro8.desarrollo.proyectojpa.model.Auto;
import ar.edu.centro8.desarrollo.proyectojpa.repository.IAutoRepository;

@Service
public class AutoService implements IAutoService {

    @Autowired
    private IAutoRepository autoRepo;

    @Override
    public List<Auto> getAutos() {
        List<Auto> listaAutos = autoRepo.findAll();
        return listaAutos;
    }

    @Override
    public void saveAuto(Auto auto) {
        autoRepo.save(auto);
    }

    @Override
    public void deleteAuto(Long id) {
        autoRepo.deleteById(id);
    }

    @Override
    public Auto findAuto(Long id) {
        Auto auto = autoRepo.findById(id).orElse(null);
        return auto;
    }

    @Override
    public void editAuto(Auto auto) {
        // Al usar save() en un objeto que ya tiene ID, JPA/Hibernate realiza un UPDATE.
        autoRepo.save(auto);
    }

}
