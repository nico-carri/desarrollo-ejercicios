package ar.edu.centro8.desarrollo.proyectojpa.controller;

import ar.edu.centro8.desarrollo.proyectojpa.model.Auto;
import ar.edu.centro8.desarrollo.proyectojpa.service.IAutoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AutoController {

    @Autowired
    private IAutoService autoServ;

    // 1. READ (Leer todos) - Muestra la vista principal (index.html)
    // URL: http://localhost:8080/
    @GetMapping("/")
    public String listarAutos(Model model) {
        // Obtiene todos los autos y los añade al modelo para que Thymeleaf los use.
        List<Auto> autos = autoServ.getAutos();
        model.addAttribute("autos", autos);

        // Crea un objeto vacío para el formulario de "Agregar Nuevo Auto"
        model.addAttribute("nuevoAuto", new Auto());

        // Retorna el nombre del template HTML
        return "index";
    }

    // 2. CREATE (Crear) - Recibe los datos del formulario de creación (index.html)
    // URL: http://localhost:8080/guardar
    @PostMapping("/guardar")
    public String guardarAuto(@ModelAttribute("nuevoAuto") Auto auto) {
        // Llama al servicio para guardar el auto
        autoServ.saveAuto(auto);

        // Redirige al método listarAutos (a la raíz /) para recargar la lista
        return "redirect:/";
    }

    // 3. DELETE (Eliminar) - Elimina un auto por ID
    // URL: http://localhost:8080/borrar/1
    @GetMapping("/borrar/{id}")
    public String eliminarAuto(@PathVariable Long id) {
        // Llama al servicio para borrar el auto por ID
        autoServ.deleteAuto(id);

        // Redirige a la página principal
        return "redirect:/";
    }

    // 4. UPDATE - Parte A: Muestra el formulario de edición (editar.html)
    // URL: http://localhost:8080/editar/1
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model) {
        // Busca el auto por ID y lo añade al modelo
        Auto auto = autoServ.findAuto(id);
        model.addAttribute("autoAEditar", auto);

        // Retorna el template para el formulario de edición
        return "editar";
    }

    // 5. UPDATE - Parte B: Recibe los datos modificados del formulario
    // (editar.html)
    // URL: http://localhost:8080/actualizar
    @PostMapping("/actualizar")
    public String actualizarAuto(@ModelAttribute("autoAEditar") Auto autoEditado) {
        // NOTA: Tu método editAuto anterior recibía muchos @RequestParam,
        // para Thymeleaf, es más simple reescribir esta lógica en el servicio
        // para que acepte el objeto Auto completo.

        // Llama al servicio para guardar los cambios (Hibernate lo detecta como UPDATE)
        autoServ.editAuto(autoEditado);

        // Redirige a la página principal
        return "redirect:/";
    }

    // [Opcional] Método para cancelar la edición y volver a la lista
    @GetMapping("/cancelar")
    public String cancelar() {
        return "redirect:/";
    }
}