const API_BASE_URL = 'http://localhost:8080/autos';

document.addEventListener('DOMContentLoaded', () => {
    cargarAutos();
    const form = document.getElementById('autoForm');
    form.addEventListener('submit', manejarEnvioFormulario);
});

// Función para mostrar mensajes de alerta
function showMessage(type, message) {
    const successMessage = document.getElementById('successMessage');
    const errorMessage = document.getElementById('errorMessage');

    // Ocultar ambos mensajes primero
    successMessage.style.display = 'none';
    errorMessage.style.display = 'none';

    if (type === 'success') {
        successMessage.textContent = message;
        successMessage.style.display = 'block';
        setTimeout(() => successMessage.style.display = 'none', 3000); // Ocultar después de 3 segundos
    } else if (type === 'error') {
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
        setTimeout(() => errorMessage.style.display = 'none', 5000); // Ocultar después de 5 segundos
    }
}


async function cargarAutos() {
    const tableBody = document.getElementById('autosTableBody');
    const mensajeCarga = document.getElementById('mensajeCarga');
    tableBody.innerHTML = '';
    mensajeCarga.style.display = 'block';

    try {
        const response = await fetch(`${API_BASE_URL}/traer`);
        
        if (!response.ok) {
            throw new Error(`Error en la petición: ${response.statusText}`);
        }

        const autos = await response.json();
        mensajeCarga.style.display = 'none';

        if (autos.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="4" style="text-align: center;">No hay automóviles registrados.</td></tr>';
            return;
        }

        autos.forEach(auto => {
            const row = tableBody.insertRow();
            
            row.insertCell().textContent = auto.id;
            row.insertCell().textContent = auto.marca;
            row.insertCell().textContent = `$${auto.precio.toFixed(2)}`;

            const actionCell = row.insertCell();

            // Botón Eliminar
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Eliminar';
            deleteButton.classList.add('btn', 'btn-danger');
            deleteButton.addEventListener('click', () => {
                eliminarAuto(auto.id, auto.marca);
            });
            actionCell.appendChild(deleteButton);
        });

    } catch (error) {
        console.error('Error al cargar automóviles:', error);
        mensajeCarga.style.display = 'none';
        tableBody.innerHTML = `<tr><td colspan="4" style="color: red; text-align: center;">Error al cargar datos: ${error.message}. Asegúrate de que el servidor Spring Boot esté corriendo y la base de datos exista.</td></tr>`;
        showMessage('error', `Error al cargar los autos: ${error.message}`);
    }
}

async function manejarEnvioFormulario(event) {
    event.preventDefault(); 

    const marca = document.getElementById('marca').value;
    const precio = parseFloat(document.getElementById('precio').value); 

    const nuevoAuto = {
        marca: marca,
        precio: precio
    };

    try {
        const response = await fetch(`${API_BASE_URL}/crear`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json' 
            },
            body: JSON.stringify(nuevoAuto) 
        });

        if (!response.ok) {
            throw new Error(`Error al crear automóvil: ${response.statusText}`);
        }

        const mensaje = await response.text(); 
        showMessage('success', mensaje); // Usar la nueva función de mensaje

        document.getElementById('autoForm').reset();
        cargarAutos(); 

    } catch (error) {
        console.error('Error al crear el automóvil:', error);
        showMessage('error', `Error al crear el auto: ${error.message}`); // Usar la nueva función de mensaje
    }
}

async function eliminarAuto(id, marca) {
    const confirmacion = confirm(`¿Estás seguro de que quieres eliminar el automóvil ${marca} con ID ${id}?`);

    if (!confirmacion) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/borrar/${id}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            throw new Error(`Error en la eliminación: ${response.statusText}`);
        }

        const mensaje = await response.text();
        showMessage('success', mensaje); // Usar la nueva función de mensaje

        cargarAutos();

    } catch (error) {
        console.error('Error al eliminar el automóvil:', error);
        showMessage('error', `Error al eliminar el auto: ${error.message}`); // Usar la nueva función de mensaje
    }
}