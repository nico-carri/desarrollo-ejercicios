package ar.edu.centro8.desarrollo.proyectojpa.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Auto {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    // REGLA DE NEGOCIO: La marca no puede ser nula en la base de datos
    @Column(nullable = false)
    private String marca;

    // REGLA DE NEGOCIO: El precio no puede ser nulo en la base de datos
    @Column(nullable = false)
    private double precio;

    // constructor sin ID, útil para la creación a partir del DTO
    public Auto(String marca, double precio) {
        this.marca = marca;
        this.precio = precio;
    }
}