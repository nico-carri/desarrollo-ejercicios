package ar.edu.centro8.desarrollo.proyectojpa.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RequestAutoDTO {

    // Regla de Negocio 'marca' no puede estar vacío
    @NotBlank(message = "La marca es obligatoria.")
    private String marca;

    // Regla de Negocio 'precio' no puede ser nulo
    @NotNull(message = "El precio es obligatorio.")
    // Regla de Negocio 'precio' debe ser mayor o igual a 0
    @Min(value = 0, message = "El precio debe ser un valor positivo.")
    private double precio;

}