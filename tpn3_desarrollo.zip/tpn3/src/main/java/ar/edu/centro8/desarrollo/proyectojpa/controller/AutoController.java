package ar.edu.centro8.desarrollo.proyectojpa.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ar.edu.centro8.desarrollo.proyectojpa.dto.RequestAutoDTO;
import ar.edu.centro8.desarrollo.proyectojpa.model.Auto;
import ar.edu.centro8.desarrollo.proyectojpa.service.IAutoService;
import jakarta.validation.Valid;

@RestController
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class AutoController {

    @Autowired
    private IAutoService autoServ;

    // GET: /autos/traer
    @GetMapping("/autos/traer")
    public List<Auto> getAutos() {
        return autoServ.getAutos();
    }

    // POST: /autos/crear - Ahora usa el DTO y la validación (@Valid)
    @PostMapping("/autos/crear")
    public String saveAuto(@RequestBody @Valid RequestAutoDTO autoDto) {
        // Conversión del DTO a la Entidad (Modelo) antes de guardar
        Auto auto = new Auto(autoDto.getMarca(), autoDto.getPrecio());

        autoServ.saveAuto(auto);
        return "El auto fue creado correctamente";
    }

    // DELETE: /autos/borrar/{id}
    @DeleteMapping("/autos/borrar/{id}")
    public String deleteAuto(@PathVariable Long id) {
        autoServ.deleteAuto(id);
        return "El auto fue eliminado correctamente";
    }

    // PUT: /autos/editar/{id_original}
    @PutMapping("/autos/editar/{id_original}")
    public Auto editAuto(@PathVariable Long id_original,
            @RequestParam(required = false, name = "id") Long nuevaId,
            @RequestParam(required = false, name = "marca") String nuevaMarca,
            @RequestParam(required = false, name = "precio") Double nuevoPrecio) {

        autoServ.editAuto(id_original, nuevaId, nuevaMarca, nuevoPrecio);

        Long idBusqueda = (nuevaId != null) ? nuevaId : id_original;
        Auto auto = autoServ.findAuto(idBusqueda);

        return auto;
    }

    // Nuevo Endpoint para la Regla de Negocio (Method Query)
    // GET: /autos/traer/marca?marca=Toyota
    @GetMapping("/autos/traer/marca")
    public ResponseEntity<List<Auto>> getAutosByMarca(@RequestParam String marca) {
        List<Auto> autos = autoServ.getAutosByMarca(marca);
        if (autos.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(autos, HttpStatus.OK);
    }
}