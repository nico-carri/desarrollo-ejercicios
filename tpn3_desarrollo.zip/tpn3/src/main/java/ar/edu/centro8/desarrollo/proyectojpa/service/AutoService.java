package ar.edu.centro8.desarrollo.proyectojpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.edu.centro8.desarrollo.proyectojpa.model.Auto;
import ar.edu.centro8.desarrollo.proyectojpa.repository.IAutoRepository;

@Service
public class AutoService implements IAutoService {

    @Autowired
    private IAutoRepository autoRepo;

    @Override
    public List<Auto> getAutos() {
        List<Auto> listaAutos = autoRepo.findAll();
        return listaAutos;
    }

    @Override
    public void saveAuto(Auto auto) {
        // Validación de existencia antes de modificar, crucial para evitar NullPointer
        if (auto != null) {
            autoRepo.save(auto);
        }
    }

    @Override
    public void deleteAuto(Long id) {
        autoRepo.deleteById(id);
    }

    @Override
    public Auto findAuto(Long id) {
        Auto auto = autoRepo.findById(id).orElse(null);
        return auto;
    }

    @Override
    public void editAuto(Long idOriginal, Long idNueva, String nuevaMarca, double nuevoPrecio) {
        // busco el objeto original
        Auto auto = this.findAuto(idOriginal);

        // verificación de existencia para evitar NullPointerException
        if (auto != null) {
            // proceso de modificación a nivel lógico
            // Se actualiza el ID solo si es diferente
            if (idNueva != null && !idNueva.equals(idOriginal)) {
                auto.setId(idNueva);
            }
            auto.setMarca(nuevaMarca);
            auto.setPrecio(nuevoPrecio);

            // guardar los cambios
            this.saveAuto(auto);
        }
    }

    @Override
    public List<Auto> getAutosByMarca(String marca) {
        // Llama al Method Query 'findByMarca' definido en IAutoRepository
        return autoRepo.findByMarca(marca);
    }
}