package ar.edu.centro8.desarrollo.proyectojpa.service;

import java.util.List;
import ar.edu.centro8.desarrollo.proyectojpa.model.Auto;

public interface IAutoService {

    public List<Auto> getAutos();

    public void saveAuto(Auto auto);

    public void deleteAuto(Long id);

    public Auto findAuto(Long id);

    public void editAuto(Long idOriginal, Long idNueva, String nuevaMarca, double nuevoPrecio);

    // regla de Negocio nuevo método para usar el Method Query
    public List<Auto> getAutosByMarca(String marca);
}