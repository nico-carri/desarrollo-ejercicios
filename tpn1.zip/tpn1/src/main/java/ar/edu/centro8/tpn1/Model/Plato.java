package ar.edu.centro8.tpn1.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Plato {
    private int id_numero;
    private String nombre;
    private double precio;
    private String descripcion;
}
