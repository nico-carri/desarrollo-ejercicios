package ar.edu.centro8.tpn1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tpn1Application {

	public static void main(String[] args) {
		SpringApplication.run(Tpn1Application.class, args);
	}

}
