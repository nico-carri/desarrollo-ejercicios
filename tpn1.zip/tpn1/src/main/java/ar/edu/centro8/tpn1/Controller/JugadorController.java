package ar.edu.centro8.tpn1.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.centro8.tpn1.Model.Jugador;

@RestController
public class JugadorController {
    private List<Jugador> jugadores = new ArrayList<>();

    @PostMapping("/jugadores")
    public double agregarJugadores(@RequestBody List<Jugador> nuevosJugadores) {
        jugadores.addAll(nuevosJugadores);

        // Calcular promedio de estatura
        double suma = 0;
        for (Jugador j : jugadores) {
            suma += j.getEstatura();
        }
        return suma / jugadores.size();
    }
}
