package ar.edu.centro8.tpn1.Controller;

public class CalculoController {

    private static final double GALON_A_LITRO = 3.78541;

    public static double convertirGalonesALitros(double galones) {
        return galones * GALON_A_LITRO;
    }

}
