package ar.edu.centro8.tpn1.Controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.centro8.tpn1.Model.Plato;

@RestController
public class MenuController {
    
    @GetMapping("/menu")
    public ArrayList<Plato> mostrarMenu() {
        ArrayList<Plato> menu = new ArrayList<>();
        menu.add(new Plato(1, "Milanesa con papas fritas", 1200, "Milanesa de carne con guarnición de papas fritas"));
        menu.add(new Plato(2, "Ensalada César", 900, "Lechuga, pollo, crutones y aderezo César"));
        menu.add(new Plato(3, "Pizza Margarita", 1500, "Pizza con salsa de tomate, mozzarella y albahaca"));
        menu.add(new Plato(4, "Spaghetti Bolognesa", 1300, "Spaghetti con salsa de carne y tomate"));
        menu.add(new Plato(5, "Hamburguesa con queso", 1100, "Hamburguesa de carne con queso, lechuga, tomate y cebolla"));
        return menu;
    }
}
