package ar.edu.centro8.tpn1.Controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;

import ar.edu.centro8.tpn1.Model.Paciente;

public class PacienteController {
    private final List<Paciente> pacientes = new ArrayList<>();

    // Constructor: cargamos algunos pacientes de ejemplo
    public PacienteController() {
        pacientes.add(new Paciente(1, "12345678", "Juan", "Pérez", LocalDate.of(2010, 5, 10)));  // menor
        pacientes.add(new Paciente(2, "23456789", "María", "Gómez", LocalDate.of(1995, 3, 20))); // mayor
        pacientes.add(new Paciente(3, "34567890", "Luis", "Fernández", LocalDate.of(2008, 8, 15))); // menor
        pacientes.add(new Paciente(4, "45678901", "Ana", "Martínez", LocalDate.of(1980, 1, 5)));  // mayor
    }

    //Listado completo de pacientes
    @GetMapping("/pacientes")
    public List<Paciente> getAllPacientes() {
        return pacientes;
    }

    //Listado de pacientes menores de edad
    @GetMapping("/pacientes/menores")
    public List<Paciente> getPacientesMenores() {
        List<Paciente> menores = new ArrayList<>();
        for (Paciente p : pacientes) {
            if (p.getFechaNacimiento().isAfter(LocalDate.now().minusYears(18))) {
                menores.add(p);
            }
        }
        return menores;
    }

}
