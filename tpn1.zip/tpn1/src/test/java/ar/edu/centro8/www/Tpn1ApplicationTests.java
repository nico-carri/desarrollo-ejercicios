package ar.edu.centro8.www;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tpn1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
